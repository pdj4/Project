-- 23년 학생 수가 가장 많은 동이리를 개설한 학과

select department.name as dept_name, club.name as club_name, T.num_student
from 
club, 
department,
(
	select student.club as ID, count(*) as num_student
	from student
	where LEFT(student.id, 4) = '2023'
	group by student.club
	having num_student = MAX(num_student)
) as T
where T.ID = club.ID AND club.department = department.ID
