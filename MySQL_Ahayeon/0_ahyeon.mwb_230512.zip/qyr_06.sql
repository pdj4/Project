-- 22년도까지 학생들이 수상했던 대회명과
-- 입상한 학생의 학과는?

SELECT contest_win.name AS ‘수상대회’,
student.major AS ‘수상학과’
FROM contest_win
JOIN student ON contest_win.student = student.ID
WHERE contest_win.year <= 2022