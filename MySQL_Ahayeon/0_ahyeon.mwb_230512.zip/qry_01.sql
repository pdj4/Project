-- 23년 실용음악과의 입학경쟁률과 24년 편성받을 예산의 조정폭?

select 
	department.name,
	T.rate,
    if(T.rate > 2.0, '+5%', if(T.rate >= 1.0, '0%', '-2%')) as budget_adjustment
from department, 
-- T: 2023년 학과별 경쟁률
(
	select recruit.department, recruit.apply / recruit.accept as rate
    from recruit
    where recruit.year = 2023
) as T
where department.ID = T.department and department.name = '실용음악';
