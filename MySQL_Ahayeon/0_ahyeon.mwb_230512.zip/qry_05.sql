-- 23학년도 입학생 중 학생수가 많은 5개 위탁학교와 그 지역

select originschool.name, originschool.district
from originschool
where originschool.ID in
(
	select *
    from
    (
		select student.originschool
		from student
		where LEFT(student.ID, 4) = '2023'
		group by student.originschool
		order by count(*) desc
		limit 5
    ) as T
    -- 구현 상의 이유로, limit 포함한 subquery를 다시 alias.
);
