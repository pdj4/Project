-- 22년까지 취업률 평균이 가장 높은 학과명과 해당 학과의 재직자가 가장 많은 협력업체

SELECT department.name, T1.avg_employeed, T2.main_company
FROM
	department,
	-- T1 : 학과별 취업률 평균을 구해서, 가장 높은 값
    (
		SELECT 
			student.major AS ID, 
			AVG(student.employeed) AS avg_employeed
		FROM student
		WHERE CAST(LEFT(student.ID, 4) AS unsigned) <= 2022
		GROUP BY student.major
		HAVING avg_employeed = MAX(avg_employeed)
	) AS T1, 
    -- T2 : 학과별 협력업체를 구해서, 고용인원이 가장 많은 주요 협력업체
	(
		SELECT 
			student.major AS ID, 
			student.company AS main_company, 
			count(student.employeed) AS num_employeed
		FROM student
        where student.company is not null
		GROUP BY student.major, student.company
		HAVING num_employeed = MAX(num_employeed)
	) AS T2
WHERE department.ID = T1.ID AND T1.ID = T2.ID ;


