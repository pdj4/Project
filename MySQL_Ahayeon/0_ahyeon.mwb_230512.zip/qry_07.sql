-- 📌  협력업체 A에 취업을 희망하는 학생이
-- 필요한 자격증을 취득할 수 있는 방과후수업은?

select afterclass.name 
from 
afterclass, 
(
	select company_require.license as required_license
    from company, company_require
    where company.name = 'A' and company.ID = company_require.company
) as T
where afterclass.license = T.required_license