-- 22년도에 지원률 미달인 학과들에서 개설한 방과후 수업들 중 최저 만족도 

select *
from afterclass
where 
afterclass.department in
(
select recruit.department
from recruit
where recruit.year = 2022 and (recruit.apply / recruit.accept) < 1.0
)
group by afterclass.department 
having afterclass.rate = min(afterclass.rate)